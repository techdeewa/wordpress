------------------ VER 1.2.1 Released on 17 Jul 2015 ---------------
Added: Woocommerce 2.3.13 support
Added: YITH WooCommerce Multi Vendor
Added: YITH WooCommerce Request a Quote
Added: YITH WooCommerce Social Login
Added: YITH WooCommerce Ajax Search
Added: YITH WooCommerce Advanced Review
Added: YITH WooCommerce Order Tracking
Added: YITH WooCommerce Pdf Invoice
Added: YITH WooCommerce Cart Message
Added: YITH WooCommerce Stripe
Added: YITH WooCommerce Authorize.net
Added: YITH WooCommerce Review Reminder
Added: YITH Infinite Scrolling
Added: YITH Live Chat

UPDATED

THEME:

readme.txt
style.css
buy-premium.php
languages/default.po
languages/yit.pot
theme/assets.php
theme/assets/images/quote.jpg
theme/assets/images/quote.png
theme/assets/images/quote_added.png
theme/assets/js/common.js
theme/assets/js/woocommerce.js
theme/panel/premium.php
theme/plugins.php
theme/woocommerce.php
woocommerce/cart/cart-totals.php
woocommerce/cart/cart.php
woocommerce/global/page-meta.php
woocommerce/product-vendors.css
woocommerce/style.css
woocommerce/yith-woocommerce-ajax-search.php
woocommerce/ywar-product-reviews.php
woocommerce/ywar-review.php

CORE:

assets/css/panel.css
assets/images/buy-premium.png
functions-core.php
lib/vendor/tgm-plugin-activation/class-tgm-plugin-activation.php
plugin-fw/*.*
yit.php
yit/Bootstrap.php
yit/Free.php
yit/Notifier.php
yit/panel/Editor.php
yit/panel/Script_Editor.php
yit/walkers/Walker_Nav_Menu_Edit.php

------------------ VER 1.2.0 Released on 24 Feb 2015 ---------------
Added: Wordpress 4.1.1 support
Added: Woocommerce 2.3.5 support
Updated: Core framework

UPDATED
readme.txt
style.css
languages/default.po
languages/yit.pot
theme/assets.php
theme/assets/js/common.js
theme/assets/js/woocommerce.js
theme/woocommerce.php
woocommerce/cart/cart-totals.php
woocommerce/cart/cart.php
woocommerce/checkout/form-checkout.php
woocommerce/checkout/payment.php
woocommerce/checkout/review-order.php
woocommerce/global/breadcrumb.php
woocommerce/single-product-reviews.php
woocommerce/single-product/add-to-cart/variable.php
woocommerce/single-product/rating.php
woocommerce/single-product/tabs/tabs.php
woocommerce/style.css
core/*.*

ADDED
woocommerce_2.2.x/*.*
theme/assets/js/woocommerce_2.3.js



------------------ VER 1.0.1 Released on 04 Feb 2015 ---------------
Added: Wordpress 4.1 support
Added: Woocommerce 2.2.11 support

UPDATED

readme.txt
style.css
languages/*.*



------------------ VER 1.0.0 Released on 13 Jan 2015 ---------------

Initial Release