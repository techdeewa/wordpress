<?php

return array(
    'slug' => 'panarea',
    'url' => 'https://yithemes.com/themes/wordpress/hi-tech-wordpress-theme/?utm_source=yith-panel&utm_medium=wpadmin&utm_content=banner-upgrade-panarea&utm_campaign=yith-admin',

    //'price' => ''   // default price, if any response from remote
    //'img' => YIT_CORE_URL .'/assets/images/buy-premium.png'   // banner image
);
