<?php
/**
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

return array(
    array(
        'name'         => 'YIT Faq',
        'slug' 		   => 'yit-faq',
        'repository'   => 'YIT Repository',
        'required' 	   => false,
        'version'      => '1.0.0',
    ),
    array(
        'name'         => 'YIT Logos',
        'slug' 		   => 'yit-logos',
        'repository'   => 'YIT Repository',
        'required' 	   => false,
        'version'      => '1.0.0',
    ),
    array(
        'name'         => 'YIT Sitemap',
        'slug' 		   => 'yit-sitemap',
        'repository'   => 'YIT Repository',
        'required' 	   => false,
        'version'      => '1.0.0',
    ),
    array(
        'name'         => 'YIT Testimonial',
        'slug' 		   => 'yit-testimonial',
        'repository'   => 'YIT Repository',
        'required' 	   => false,
        'version'      => '1.0.0',
    ),
    array(
        'name'         => 'WooCommerce',
        'slug'         => 'woocommerce',
        'required'     => true,
        'version'      => '2.1.9',
    ),

    defined( 'YITH_YWZM_PREMIUM' ) ? array() : array(
        'name' 		=> 'YITH WooCommerce Zoom Magnifier',
        'slug' 		=> 'yith-woocommerce-zoom-magnifier',
        'required' 	=> false,
        'version'   => '1.1.1',
    ),
    defined( 'YITH_WCWL_PREMIUM' ) ? array() : array(
        'name' 		=> 'YITH WooCommerce Wishlist',
        'slug' 		=> 'yith-woocommerce-wishlist',
        'required' 	=> false,
        'version'   => '1.1.2',
    ),

    defined( 'YITH_WCCL_PREMIUM' ) ? array() : array(
        'name'      => 'YITH WooCommerce Colors and Labels Variations',
        'slug'      => 'yith-woocommerce-colors-labels-variations',
        'repository'   => 'YIT Repository',
        'required' 	=> false,
        'version' 	=> '1.1.2'
    ),


    defined( 'YITH_WCAN_PREMIUM' ) ? array() : array(
        'name' 		=> 'YITH WooCommerce Ajax Navigation',
        'slug' 		=> 'yith-woocommerce-ajax-navigation',
        'required' 	=> false,
        'version'   => '1.3.1'
    ),

    defined( 'YITH_WCAS_PREMIUM' ) ? array() : array(
        'name' 		=> 'YITH WooCommerce Ajax Search',
        'slug' 		=> 'yith-woocommerce-ajax-search',
        'required' 	=> false,
        'version'   => '1.1.1'
    ),

    defined( 'YWCTM_PREMIUM' ) ? array() : array(
        'name'      => 'YITH WooCommerce Catalog Mode',
        'slug'      => 'yith-woocommerce-catalog-mode',
        'required'  => false,
        'version'   => '1.0.0'
    ),

    defined( 'YITH_YWOT_PREMIUM' ) ? array() : array(
        'name'         => 'YITH Woocommerce Order Traking',
        'slug' 		   => 'yith-woocommerce-order-tracking',
        'required' 	   => false,
        'version'      => '1.0.0',
    ),

    defined( 'YITH_YWAR_PREMIUM' ) ? array() : array(
        'name'         => 'YITH Woocommerce Advanced Reviews',
        'slug' 		   => 'yith-woocommerce-advanced-reviews',
        'required' 	   => false,
        'version'      => '1.0.0',
    ),

    defined( 'YITH_YWRAQ_PREMIUM' ) ? array() : array(
        'name'      => 'YITH WooCommerce Request a Quote',
        'slug'      => 'yith-woocommerce-request-a-quote',
        'required'  => false,
        'version'   => '1.0.0'
    ),

    defined( 'YITH_WPV_PREMIUM' ) ? array() : array(
        'name'         => 'YITH WooCommerce Multi Vendor',
        'slug'         => 'yith-woocommerce-product-vendors',
        'required'     => false,
        'version'      => '1.0.0',
    ) ,

    defined( 'YITH_YWSL_PREMIUM' ) ? array() : array(
        'name'         => 'YITH WooCommerce Social Login',
        'slug'         => 'yith-woocommerce-social-login',
        'required'     => false,
        'version'      => '1.0.0',
    ),

    defined( 'YITH_INFS_PREMIUM' ) ? array() : array(
        'name'   => 'YITH Infinite Scrolling',
        'slug'   => 'yith-infinite-scrolling',
        'required'  => false,
        'version'   => '1.0.0'
    ),
    defined( 'YLC_PREMIUM' ) ? array() : array(
        'name'         => 'YITH Live Chat',
        'slug'         => 'yith-live-chat',
        'required'     => false,
        'version'      => '1.0.0',
    )
);