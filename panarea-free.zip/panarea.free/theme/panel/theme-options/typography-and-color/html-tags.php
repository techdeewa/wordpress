<?php
/**
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

/**
 * Return an array with the options for Theme Options > Typography and Color > HTML Tags
 *
 * @package Yithemes
 * @author Andrea Grillo <andrea.grillo@yithemes.com>
 * @author Antonio La Rocca <antonio.larocca@yithemes.it>
 * @since 2.0.0
 * @return mixed array
 *
 */
return array(

    /* Typography and Color > HTML Tags General Settings */
    array(
        'type' => 'title',
        'name' => __( 'HTML Tags General Settings', 'yit' ),
        'desc' => ''
    ),

    array(
        'id' => 'typography-link-color',
        'type' => 'colorpicker',
        'variations' => array(
            'normal' => __( 'Links', 'yit' ),
            'hover'  => __( 'Links hover', 'yit' )
        ),
        'name' => __( 'Links', 'yit' ),
        'desc' => __( 'Select the colors to use for the links in normal state and on hover.', 'yit' ),
        'std'  => array(
            'color' => array(
                'normal' => '#a4bc48',
                'hover'  => '#799707'
            )
        ),
        'style' => array(
            'normal' => array(
                'selectors'   => '',
                'properties'  => 'color'
            ),
            'hover' => array(
                'selectors'   => '',
                'properties'  => 'color'
            )
        ),
        'linked_to' => array(
            'normal' => 'theme-color-1',
            'hover'  => 'theme-color-2'
        ),
        'disabled' => true
        
    ),

    array(
        'id' => 'typography-p-font',
        'type' => 'typography',
        'name' => __( 'Paragraphs', 'yit' ),
        'desc' => __( 'Select the type to use for the p.', 'yit' ),
        'min' => 1,
        'max' => 80,
        'default_font_id' => 'typography-website-paragraph',
        'std'   => array(
            'size'      => 16,
            'unit'      => 'px',
            'family'    => 'default',
            'style'     => 'regular',
            'color'     => '#555555',
            'align'     => 'left',
            'transform' => 'none',
        ),
        'style' => array(
            'selectors'   => '',
            'properties'  => 'font-size,
                              font-family,
                              font-weight,
                              color,
                              text-transform,
                              text-align'
        ),
        'disabled' => true
    ),

    array(
        'id' => 'typography-h1-font',
        'type' => 'typography',
        'name' => __( 'Headings 1 font', 'yit' ),
        'desc' => __( 'Select the type to use for the h1.', 'yit' ),
        'min' => 1,
        'max' => 80,
        'default_font_id' => 'typography-website-title',
        'std'   => array(
            'size'      => 28,
            'unit'      => 'px',
            'family'    => 'default',
            'style'     => 'regular',
            'color'     => '#000000',
            'align'     => 'left',
            'transform' => 'none',
        ),
        'style' => array(
            'selectors'   => '',
            'properties'  => 'font-size,
                              font-family,
                              font-weight,
                              color,
                              text-transform,
                              text-align'
        ),
        'disabled' => true
        
    ),

    array(
        'id' => 'typography-h2-font',
        'type' => 'typography',
        'name' => __( 'Headings 2 font', 'yit' ),
        'desc' => __( 'Select the type to use for the h2.', 'yit' ),
        'min' => 1,
        'max' => 80,
        'default_font_id' => 'typography-website-title',
        'std'   => array(
            'size'      => 20,
            'unit'      => 'px',
            'family'    => 'default',
            'style'     => 'regular',
            'color'     => '#000000',
            'align'     => 'left',
            'transform' => 'none',
        ),
        'style' => array(
            'selectors'   => '',
            'properties'  => 'font-size,
                              font-family,
                              font-weight,
                              color,
                              text-transform,
                              text-align'
        ),
        'disabled' => true
        
    ),

    array(
        'id' => 'typography-h3-font',
        'type' => 'typography',
        'name' => __( 'Headings 3 font', 'yit' ),
        'desc' => __( 'Select the type to use for the h3.', 'yit' ),
        'min' => 1,
        'max' => 80,
        'default_font_id' => 'typography-website-title',
        'std'   => array(
            'size'      => 18,
            'unit'      => 'px',
            'family'    => 'default',
            'style'     => '700',
            'color'     => '#000000',
            'align'     => 'left',
            'transform' => 'uppercase',
        ),
        'style' => array(
            'selectors'   => '',
            'properties'  => 'font-size,
                              font-family,
                              font-weight,
                              color,
                              text-transform,
                              text-align'
        ),
        'disabled' => true
        
    ),

    array(
        'id' => 'typography-h4-font',
        'type' => 'typography',
        'name' => __( 'Headings 4 font', 'yit' ),
        'desc' => __( 'Select the type to use for the h4.', 'yit' ),
        'min' => 1,
        'max' => 80,
        'default_font_id' => 'typography-website-title',
        'std'   => array(
            'size'      => 16,
            'unit'      => 'px',
            'family'    => 'default',
            'style'     => 'regular',
            'color'     => '#000000',
            'align'     => 'left',
            'transform' => 'none',
        ),
        'style' => array(
            'selectors'   => '',
            'properties'  => 'font-size,
                              font-family,
                              font-weight,
                              color,
                              text-transform,
                              text-align'
        ),
        'disabled' => true
        
    ),

    array(
        'id' => 'typography-h5-font',
        'type' => 'typography',
        'name' => __( 'Headings 5 font', 'yit' ),
        'desc' => __( 'Select the type to use for the h5.', 'yit' ),
        'min' => 1,
        'max' => 80,
        'default_font_id' => 'typography-website-title',
        'std'   => array(
            'size'      => 14,
            'unit'      => 'px',
            'family'    => 'default',
            'style'     => 'regular',
            'color'     => '#000000',
            'align'     => 'left',
            'transform' => 'none',
        ),
        'style' => array(
            'selectors'   => '',
            'properties'  => 'font-size,
                              font-family,
                              font-weight,
                              color,
                              text-transform,
                              text-align'
        ),
        'disabled' => true
        
    ),

    array(
        'id' => 'typography-h6-font',
        'type' => 'typography',
        'name' => __( 'Headings 6 font', 'yit' ),
        'desc' => __( 'Select the type to use for the h6.', 'yit' ),
        'min' => 1,
        'max' => 80,
        'default_font_id' => 'typography-website-title',
        'std'   => array(
            'size'      => 12,
            'unit'      => 'px',
            'family'    => 'default',
            'style'     => 'regular',
            'color'     => '#000000',
            'align'     => 'left',
            'transform' => 'none',
        ),
        'style' => array(
            'selectors'   => '',
            'properties'  => 'font-size,
                              font-family,
                              font-weight,
                              color,
                              text-transform,
                              text-align'
        ),
        'disabled' => true
        
    )
);

